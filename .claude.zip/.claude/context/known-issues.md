# 已知问题列表

> **维护规则**: 发现新问题时添加，修复后删除
> **最后更新**: 2025-12-15

---

## 🔴 P0 - 阻塞性问题（必须修复）

### [BUG-001] OCR坐标偏差导致区块分割失败
**发现时间**: 2025-12-10
**影响范围**: 所有使用OCR定位的功能

**现象**：
- OCR识别的关键词坐标偏移实际位置约50px
- 导致`image_splitter.py`中的区块分割不准确
- 部分关键词（如"Total Sales"）定位到错误的位置

**复现步骤**：
```bash
python scripts/visualize_keywords_only.py PdfData/MP_01142025_statement_summary.pdf
# 观察：关键词框偏移文字位置约50px
```

**根本原因**（初步分析）：
1. DPI转换计算错误（300 DPI → 72 DPI的转换比例）
2. 页边距未正确考虑（PDF默认12px页边距）
3. 校准文件(`ocr_calibration_300dpi.pkl`)过时

**临时解决方案**：
```python
# 在ocr_engine.py中手动调整offset
y_corrected = y_raw * 0.24 + 20  # 增加offset从12到20
```

**正式解决方案**（进行中）：
- [ ] 重新测量PDF的实际页边距
- [ ] 更新校准函数算法
- [ ] 生成新的校准文件
- [ ] 全面测试6个PDF样本

**相关文件**：
- `backend/app/services/ocr_engine.py:180-220`
- `scripts/create_calibration.py`
- `calibration_data/ocr_calibration_300dpi.pkl`

**预计修复时间**: 2天（本周内完成）

---

## 🟡 P1 - 重要问题（需要修复）

### [BUG-002] 中文标点识别错误
**发现时间**: 2025-12-05
**影响范围**: 包含中文的PDF（约10%的输入文件）

**现象**：
- 全角逗号（，）识别成句号（。）
- 全角冒号（：）识别成分号（；）
- 准确率下降约5%

**复现步骤**：
```python
from backend.app.services.ocr_engine import OCREngine

engine = OCREngine()
result = engine.recognize("test_chinese.png")
# 预期："金额：1000.00"
# 实际："金额；1000.00"  # 冒号识别错误
```

**根本原因**：
PaddleOCR的语言模型设置为'en'（英文），对中文标点支持不足

**解决方案**：
```python
# 方案1：切换到中英文混合模型（推荐）
self._ocr_config['lang'] = 'ch'  # 或 'en,ch'

# 方案2：后处理阶段修正
def fix_chinese_punctuation(text):
    """修正中文标点识别错误."""
    replacements = {
        '。': '，',  # 句号改逗号（根据上下文）
        '；': '：',  # 分号改冒号
    }
    # 实现上下文判断逻辑...
    return corrected_text
```

**影响评估**：
- 方案1会略微增加识别时间（+5%）
- 但准确率提升显著（+8%）

**预计修复时间**: 0.5天

---

### [BUG-003] 大文件处理内存泄漏
**发现时间**: 2025-12-12
**影响范围**: 处理>50页的大PDF文件

**现象**：
- 处理100页PDF后内存占用>8GB
- 系统变慢，可能触发OOM（内存不足）

**复现步骤**：
```bash
python scripts/test_batch_pdf_split.py --input large_pdf/ --pages 100
# 观察内存占用逐渐增长
```

**根本原因**：
- 图像对象未及时释放（缺少`del`语句）
- 中间结果累积在列表中未清理
- 未定期调用`gc.collect()`

**临时解决方案**：
```python
# 逐页处理时立即释放
for page_num in range(page_count):
    image = process_page(page_num)
    result = ocr.recognize(image)
    del image  # 立即释放
    gc.collect()  # 定期垃圾回收
```

**正式解决方案**：
- [ ] 在`pdf_parser.py`中添加内存管理代码
- [ ] 在`image_splitter.py`中添加内存释放逻辑
- [ ] 添加内存监控日志
- [ ] 编写内存泄漏测试用例

**相关文件**：
- `backend/app/services/pdf_parser.py:450-500`
- `backend/app/services/image_splitter.py:800-850`

**预计修复时间**: 1天

---

## 🟢 P2 - 已知限制（可接受）

### [LIMIT-001] 单页处理时间较长
**发现时间**: 2025-11-25
**影响范围**: 所有OCR识别

**现象**：
- CPU模式：处理一页PDF需要15秒
- 批量处理100页需要25分钟

**原因**：
- 未启用GPU加速
- 图像预处理耗时（约3秒/页）
- OCR模型推理耗时（约10秒/页）
- 后处理耗时（约2秒/页）

**可接受理由**：
- 这是PaddleOCR在CPU模式下的正常性能
- 对于小批量处理（<10页）可接受
- 大批量处理时可启用GPU加速（提速5倍）

**优化建议**：
```python
# 方案1：启用GPU（最有效）
engine = OCREngine(use_gpu=True)
# 速度：15秒 → 3秒（提速5倍）

# 方案2：并行处理（CPU多核）
# 使用ProcessPoolExecutor并行处理多页
# 速度：15秒 × 100页 = 1500秒 → 400秒（提速3.75倍）

# 方案3：降低DPI（牺牲少量准确率）
result = engine.recognize(image, dpi=250)
# 速度：15秒 → 10秒（提速33%）
# 准确率：96% → 93%（下降3%）
```

**计划优化时间**: Phase 2后期（当前阶段不优先）

---

### [LIMIT-002] 不支持手写体识别
**发现时间**: 2025-11-20
**影响范围**: 手写PDF（约1%的输入文件）

**现象**：
- 手写文字识别准确率<50%
- 部分手写数字识别为其他字符

**原因**：
PaddleOCR默认模型针对印刷体优化，手写体支持有限

**可接受理由**：
- Walmart报表99%是打印PDF，极少手写
- 手写识别需要专门的模型（如CRNN + CTC）
- 投入产出比不高

**替代方案**：
- 遇到手写PDF时，提示用户人工处理
- 或使用专门的手写体OCR服务（如Google Vision API）

---

### [LIMIT-003] 表格识别准确率有限
**发现时间**: 2025-12-01
**影响范围**: 复杂表格（多层表头、合并单元格）

**现象**：
- 简单表格（单层表头）：识别准确率90%
- 复杂表格（多层表头）：识别准确率60-70%
- 合并单元格识别错误

**原因**：
- PaddleOCR主要识别文字，表格结构识别能力有限
- `pdfplumber`的表格提取依赖于线条检测，对某些表格失效

**临时解决方案**：
```python
# 结合多种方法提取表格
# 1. 先用pdfplumber提取（准确率高）
tables = pdfplumber_extract_tables(pdf)

# 2. 如果失败，用OCR + 规则引擎
if not tables:
    tables = ocr_extract_tables(pdf)

# 3. 人工验证（可选）
if confidence < 0.8:
    mark_for_manual_review(tables)
```

**长期计划**：
- Phase 3考虑引入专门的表格识别模型（如TableNet）

---

## 📋 问题统计

| 优先级 | 未修复 | 已修复 | 总计 |
|--------|--------|--------|------|
| P0     | 1      | 0      | 1    |
| P1     | 2      | 0      | 2    |
| P2     | 3      | 0      | 3    |
| **总计** | **6** | **0** | **6** |

---

## 🔄 已修复问题（归档）

### [FIXED-001] PDF转图片DPI不一致
**修复时间**: 2025-12-08
**问题**: pdf2image转换的图片DPI与设定值不一致
**解决方案**: 明确指定`dpi`参数，并验证输出图片的实际DPI

### [FIXED-002] 日志输出过于冗余
**修复时间**: 2025-12-05
**问题**: DEBUG级别日志输出过多，影响性能
**解决方案**: 调整日志级别，仅关键步骤输出INFO

---

## 📞 报告新问题

发现新问题时，请按以下格式添加：

```markdown
### [BUG-XXX] 问题简短描述
**发现时间**: YYYY-MM-DD
**影响范围**: 描述影响的功能和用户

**现象**：
- 详细描述问题的表现

**复现步骤**：
1. 步骤1
2. 步骤2
3. 预期结果 vs 实际结果

**根本原因**（如已知）：
- 分析原因

**临时解决方案**（如有）：
- 临时绕过方法

**相关文件**：
- 文件路径和行号

**预计修复时间**: X天
```

---

**最后更新**: 2025-12-15 | **维护者**: 开发团队
