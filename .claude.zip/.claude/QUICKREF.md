# Claude快速参考卡

> **用途**: 3秒内快速决策，无需翻阅详细文档
> **更新**: 2025-12-16 | **版本**: v1.0

---

## ⚡ 快速决策树

### 📝 代码质量检查 (5秒)
```
✅ 有docstring? → ✅ 有类型注解? → ✅ 有测试? → 通过
❌ 任何一项缺失 → 必须补充后再继续
```

### 🔍 OCR DPI选择 (3秒)
```
清晰PDF → 300 DPI (推荐)
模糊PDF → 400 DPI
极模糊 → 600 DPI (最后尝试)
```

### 🧪 测试覆盖要求 (3秒)
```
核心模块 (services/) → >80%
工具函数 (utils/) → >60%
API层 (待实现) → >90%
```

### 📁 文件路径规则 (2秒)
```
测试代码 → scripts/test/test-code/
测试输出 → scripts/test/test-output/
测试文档 → scripts/test/test-md/
核心代码 → backend/app/services/
```

---

## 🚨 强制约束 (必须遵守)

### MUST (必须做)
```
✅ 每个函数有docstring (包含Args/Returns/Example)
✅ 魔法数字必须注释或定义常量
✅ 使用logger而非print
✅ 先写测试再提交代码
✅ 坐标校准必须使用calibration_data/
```

### MUST NOT (禁止做)
```
❌ 提交未注释的函数
❌ 使用裸露数字 (如 if x > 0.8)
❌ 提交测试覆盖率<80%的核心模块
❌ 使用print()调试 (必须用logger)
❌ 跳过测试直接提交
```

---

## 🎯 任务路由表 (自动加载)

| 用户关键词 | 加载文档 | 加载时间 |
|-----------|----------|----------|
| OCR/识别/坐标/DPI | specs/ocr-guide.md | 2秒 |
| 测试/pytest/单元测试 | CORE.md#测试规范 | 1秒 |
| 数据库/SQL/表结构 | CORE.md#数据库设计 | 1秒 |
| 性能/优化/加速 | CORE.md#性能优化 | 1秒 |
| 注释/文档/docstring | AI-ASSIST.md | 1秒 |
| 审查/review/检查 | AI-ASSIST.md#代码审查 | 1秒 |

---

## 📊 常用命令速查

### OCR测试
```bash
# 可视化关键词定位
python scripts/quick_visualize.py <PDF路径>

# 生成坐标校准
python scripts/create_calibration.py
```

### 环境管理
```bash
# 激活虚拟环境
source venv/bin/activate

# 安装依赖 (使用阿里云镜像)
pip install -i https://mirrors.aliyun.com/pypi/simple/ -r backend/requirements.txt
```

### 测试运行
```bash
# 运行单元测试
pytest backend/tests/unit/ -v

# 生成覆盖率报告
pytest --cov=backend/app --cov-report=html backend/tests/
```

---

## 🔧 技术栈速查

| 分类 | 技术 | 版本 | 用途 |
|------|------|------|------|
| OCR | PaddleOCR | 2.7.3 | 文字识别 |
| PDF | pdfplumber | 0.11.0 | PDF解析 |
| 图像 | OpenCV | 4.6.0.66 | 图像处理 |
| Python | 3.11.9 | pyenv | ARM64优化 |
| 环境 | venv | - | 虚拟环境 |

---

## 🎓 魔法咒语 (快捷指令)

| 用户输入 | Claude执行 |
|---------|-----------|
| `详细注释 <文件>` | 添加超详细注释 |
| `测试 <文件>` | 生成单元测试 |
| `审查 <文件>` | 完整代码审查 |
| `优化 <函数>` | 性能优化分析 |

---

## 📍 当前项目状态 (2025-12-16)

### 开发阶段
```
Phase 2: PDF解析 (70%) ← 当前阶段
```

### 当前优先级
```
P0: 配置文档优化 (进行中)
P1: 执行Steps 1-3测试
P2: 坐标校准优化
```

### 已知问题
```
- PaddleOCR初始化慢 (5-10分钟首次)
- 坐标校准偏差 (~10px)
```

---

## 🔍 问题排查速查

### OCR识别慢 (>30秒/页)
```
1. 检查GPU: paddle.is_compiled_with_cuda()
2. 降低DPI: 300 → 250
3. 启用缓存: OCRCache()
```

### 坐标偏移严重 (>10px)
```
1. 检查DPI匹配: 校准文件DPI = 识别DPI
2. 可视化验证: quick_visualize.py
3. 重新生成校准: create_calibration.py
```

### 内存占用高 (>8GB)
```
1. 逐页处理: 不一次性加载
2. 及时释放: del image; gc.collect()
3. 减小批次: rec_batch_num = 3
```

---

## ✅ 自我检查清单 (Claude专用)

### 写代码前
```
□ 理解需求了吗?
□ 查阅相关文档了吗?
□ 有更好的方案吗?
```

### 写代码时
```
□ 添加详细注释了吗?
□ 注释解释了"为什么"吗?
□ 魔法数字都注释了吗?
□ 使用logger而非print吗?
```

### 写代码后
```
□ 写测试了吗? (正常+边界+异常)
□ 测试通过了吗?
□ 覆盖率>80%吗?
□ 性能合理吗?
```

### 回复用户前
```
□ 解释清楚了吗? (分层解释)
□ 有示例吗? (代码示例)
□ 有验证吗? (运行验证)
□ 有下一步建议吗?
```

---

**END OF QUICKREF**

*配置版本: v1.0 | 创建时间: 2025-12-16 | 文件行数: 约200行*
