# Walmart PDF解析系统 - Claude开发助手配置

> **版本**: v4.1 | **更新**: 2025-12-16 | **架构**: 分层配置体系

---

## 🎯 项目概览

### 一句话描述
**自动化处理沃尔玛市场（Walmart Marketplace）财务对账单的PDF报表识别和数据分析系统**

### 核心能力
- PDF自动解析（pdfplumber）
- OCR文字识别（PaddleOCR）
- 智能图像分割（OpenCV）
- 数据结构化提取（正则+规则引擎）
- 后续：Web API + 数据库存储

---

## 📊 当前状态

### 开发阶段
```
Phase 1: 基础架构 ████████░░ 80%
Phase 2: PDF解析   ███████░░░ 70% ← 当前阶段
Phase 3: Web开发   ░░░░░░░░░░  0%
Phase 4: 数据分析  ░░░░░░░░░░  0%
Phase 5: 部署上线  ░░░░░░░░░░  0%
```

### 本周优先级（2025-12-16 ~ 2025-12-22）
```
P0 🔴 配置文档优化 (已完成) ✅
P1 🟡 执行Steps 1-3完整测试
P2 🟢 坐标校准优化
```

### 代码统计
- **核心代码**: ~4000行Python（6个服务文件）
- **测试脚本**: 2个工具脚本（已清理）
- **测试覆盖率**: ~10%（需提升）
- **项目大小**: 1.6GB (venv占1.5GB)

---

## ⚡ 快速命令

### OCR测试与可视化
```bash
# 快速可视化OCR关键词定位 (最常用)
python scripts/quick_visualize.py PdfData/MP_01142025_statement_summary.pdf

# 生成坐标校准数据
python scripts/create_calibration.py
```

### 单元测试 (待完善)
```bash
# 运行所有单元测试
pytest backend/tests/unit/ -v

# 生成测试覆盖率报告
pytest --cov=backend/app --cov-report=html backend/tests/
```

### 环境管理
```bash
# 激活虚拟环境
source venv/bin/activate

# 安装依赖 (使用阿里云镜像)
pip install -i https://mirrors.aliyun.com/pypi/simple/ -r backend/requirements.txt
```

---

## 📚 配置文档索引

### Level 0: 快速参考（优先阅读）
- **[QUICKREF.md](QUICKREF.md)** - ⚡ 快速参考卡（3秒决策）
  - 快速决策树
  - 强制约束清单
  - 任务路由表
  - 常见问题速查

### Level 1: 核心配置（必读）
- **[CORE.md](CORE.md)** - 核心开发规范
  - 项目架构说明
  - 代码注释铁律
  - 技术栈约定
  - 测试规范
  - 数据库设计

- **[AI-ASSIST.md](AI-ASSIST.md)** - AI辅助开发配置
  - 超详细注释策略
  - 单元测试生成模板
  - 代码审查检查清单
  - 魔法咒语快捷指令

### Level 2: 专项深度指南（按需加载）
- **[specs/ocr-guide.md](specs/ocr-guide.md)** - OCR识别详细策略
  - DPI选择矩阵
  - 坐标校准详解
  - 常见问题排查手册
  - 性能优化技巧

### Level 3: 动态上下文（每周更新）
- **[context/current-sprint.md](context/current-sprint.md)** - 当前冲刺目标
- **[context/known-issues.md](context/known-issues.md)** - 已知问题列表
- **[context/error-patterns.md](context/error-patterns.md)** - 历史错误模式
- **[context/recent-changes.md](context/recent-changes.md)** - 最近重要变更

---

## 🏗️ 项目结构速览

```
walmart-a/                  (1.6GB total)
├── .claude/                # Claude配置（当前目录）
│   ├── CLAUDE.md          # 本文件（主配置）
│   ├── QUICKREF.md        # 快速参考卡 ⚡ NEW
│   ├── CORE.md            # 核心开发规范
│   ├── AI-ASSIST.md       # AI辅助配置
│   ├── specs/             # 专项深度指南
│   │   └── ocr-guide.md
│   ├── context/           # 动态上下文
│   │   ├── current-sprint.md
│   │   ├── known-issues.md
│   │   ├── error-patterns.md  ⚡ NEW
│   │   └── recent-changes.md
│   └── settings.local.json
│
├── backend/                # 后端核心代码 (4.1MB)
│   ├── app/
│   │   ├── services/      # 业务逻辑层
│   │   │   ├── ocr_engine.py           # OCR引擎封装
│   │   │   ├── pdf_parser.py           # PDF解析器
│   │   │   ├── image_splitter.py       # 图像分割器
│   │   │   ├── section_splitter.py     # 区块分割
│   │   │   └── pdf_section_splitter.py # PDF区块处理
│   │   ├── utils/         # 工具函数
│   │   ├── models/        # 数据模型（待实现）
│   │   └── schemas/       # Pydantic schemas（待实现）
│   ├── tests/             # 测试目录
│   │   ├── unit/          # 单元测试（待完善）
│   │   ├── fixtures/      # 测试fixtures
│   │   └── test_data/     # 测试数据
│   │       └── sample_pdfs/  # 6个测试PDF
│   └── requirements.txt
│
├── scripts/                # 开发脚本 (24KB)
│   ├── create_calibration.py    # 坐标校准生成
│   ├── quick_visualize.py       # OCR可视化工具
│   └── test/               # 测试目录规范
│       ├── test-code/     # 所有测试代码
│       ├── test-output/   # 所有测试输出
│       └── test-md/       # 所有测试文档
│
├── calibration_data/       # OCR坐标校准数据 (332KB)
│   └── ocr_calibration_300dpi.pkl
│
├── PdfData/                # 测试PDF样本 (3.5MB)
├── venv/                   # Python 3.11.9虚拟环境 (1.5GB)
└── README_安装说明.txt
```

---

## 🔧 技术栈详情

### 核心依赖
| 分类 | 库名 | 版本 | 用途 |
|------|------|------|------|
| PDF处理 | pdfplumber | 0.11.0 | PDF解析（文本+表格） |
| PDF处理 | pdf2image | 1.16.3 | PDF转图片 |
| OCR识别 | paddleocr | 2.7.3 | 中文OCR引擎 |
| OCR识别 | paddlepaddle | 2.6.2 | PaddleOCR底层框架 |
| 图像处理 | opencv-python | 4.6.0.66 | 图像预处理+分割 |
| 图像处理 | Pillow | 10.2.0 | 图像基础操作 |
| 数据处理 | pandas | 2.1.4 | 数据分析 |
| 测试框架 | pytest | 7.4.3 | 单元测试 |

**环境要求**:
- Python 3.11.9 (pyenv)
- macOS ARM64 (Apple Silicon)
- NumPy 1.26.4 (兼容PaddleOCR)

**依赖下载**: 优先使用阿里云/清华镜像源加速下载

---

## 🎓 如何使用此配置

### 对于Claude助手（重要！）

#### 首次接触项目
1. **快速了解**：精读 [QUICKREF.md](QUICKREF.md)（3分钟）
2. **核心规范**：精读 [CORE.md](CORE.md) 和 [AI-ASSIST.md](AI-ASSIST.md)（10分钟）
3. **当前任务**：查看 [context/current-sprint.md](context/current-sprint.md)

#### 任务路由（按需加载）
```
用户提到【OCR/识别/坐标/DPI】
  → 加载 specs/ocr-guide.md

用户提到【测试/pytest/单元测试】
  → 加载 CORE.md#测试规范

用户提到【数据库/SQL/表结构】
  → 加载 CORE.md#数据库设计

用户提到【性能/优化/加速】
  → 加载 CORE.md#性能优化

用户提到【注释/文档/docstring】
  → 加载 AI-ASSIST.md

用户提到【审查/review/检查】
  → 加载 AI-ASSIST.md#代码审查
```

#### 工作流程
1. **理解需求** → 查看 QUICKREF.md 决策树
2. **编写代码** → 遵循 CORE.md 规范
3. **添加注释** → 遵循 AI-ASSIST.md 注释策略
4. **编写测试** → 遵循 CORE.md 测试规范
5. **自我检查** → 使用 QUICKREF.md 检查清单
6. **遇到问题** → 查看 context/known-issues.md 和 context/error-patterns.md

### 对于人类开发者
1. **理解项目**：先读本文件（CLAUDE.md）
2. **快速参考**：遇到问题先查 [QUICKREF.md](QUICKREF.md)
3. **编写代码**：遵循 [CORE.md](CORE.md) 的规范
4. **更新状态**：每周更新 [context/](context/) 目录

---

## 🚨 开发铁律（必须遵守）

> **详细规范请查看**: [QUICKREF.md](QUICKREF.md) 或 [CORE.md](CORE.md)

### 代码质量 (MUST)
- ✅ 每个函数都有详细docstring
- ✅ 魔法数字必须注释或定义为常量
- ✅ 使用logger记录日志（禁止print）
- ✅ 先写测试，再提交代码

### OCR处理 (MUST)
- ✅ 默认DPI：300（平衡质量与性能）
- ✅ 坐标校准：必须使用calibration_data/校准函数
- ✅ 错误容忍：OCR失败不中断流程

### 测试要求 (MUST)
- ✅ 单元测试覆盖率：核心模块 > 80%
- ✅ 测试分类：正常情况 + 边界情况 + 异常情况
- ✅ 测试数据：统一放在 backend/tests/test_data/

### 文件组织 (MUST)
- ✅ 测试代码：scripts/test/test-code/
- ✅ 测试输出：scripts/test/test-output/
- ✅ 测试文档：scripts/test/test-md/

---

## 📞 获取帮助

### 遇到问题？
1. **快速查询**：[QUICKREF.md](QUICKREF.md) - 问题排查速查
2. **已知问题**：[context/known-issues.md](context/known-issues.md)
3. **历史错误**：[context/error-patterns.md](context/error-patterns.md)
4. **OCR排查**：[specs/ocr-guide.md](specs/ocr-guide.md)

### 更新此配置
- **CLAUDE.md**（本文件）：项目状态变化时更新（如Phase切换）
- **QUICKREF.md**：常用命令或规范变更时更新
- **CORE.md**：技术栈或开发规范变化时更新（较少）
- **context/**：每周更新一次，记录当前冲刺和新问题

---

## ✨ 配置特点

本配置采用**分层加载**设计：
- **Level 0**（QUICKREF）：3秒决策 → 50行
- **Level 1**（CORE+AI）：核心规范 → 约1400行
- **Level 2**（specs/）：专项深度 → 按需加载
- **Level 3**（context/）：动态信息 → 每周更新

**优势**：
- ⚡ 快速决策优先（QUICKREF.md）
- 🎯 按需加载详细配置，避免token浪费
- 🔄 动态信息独立，核心配置稳定
- 📈 分层渐进，提高交互效率

---

## 📊 配置优化记录

### v4.1 (2025-12-16晚)
- ✅ 优化 specs/ocr-guide.md（从750行压缩至382行，减少49%）
- ✅ 创建 templates/docstring-template.py（7种场景模板，519行）
- ✅ 优化OCR指南结构：快速参考+详细说明分离
- ✅ 增强坐标校准文档（代码示例+排查清单）
- ✅ 备份旧版本为ocr-guide-v3-backup.md

### v4.0 (2025-12-16)
- ✅ 新增 QUICKREF.md 快速参考卡
- ✅ 新增 context/error-patterns.md 历史错误记录
- ✅ 精简主配置文件到150行
- ✅ 建立任务路由表和按需加载机制
- ✅ 清理项目目录（释放1.5GB空间）

### v3.0 (2025-12-15)
- 建立三级配置体系
- 完善OCR指南和测试规范

---

**END OF CLAUDE.md**

*配置版本: v4.1 | 最后更新: 2025-12-16 | 文件行数: 约235行*
