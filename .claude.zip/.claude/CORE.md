# 核心开发规范（精简版）

> **目标读者**: Claude助手 + 人类开发者
> **更新频率**: 技术栈或架构变更时
> **最后更新**: 2025-12-16
> **版本**: v4.0（精简版）

---

## 📐 项目架构设计

### 架构理念
```
分层架构 + 服务导向
├── Services层：核心业务逻辑（当前重点）
├── Models层：数据模型（Phase 3实现）
├── API层：Web接口（Phase 3实现）
└── Utils层：通用工具函数
```

### 核心模块关系图
```
PDF文件
  ↓
[pdf_parser.py] - PDF解析器
  ↓
PDF → 图片
  ↓
[ocr_engine.py] - OCR引擎
  ↓
文字+坐标
  ↓
[image_splitter.py] - 图像分割器
  ↓
区块分割
  ↓
[section_splitter.py] - 区块提取
  ↓
结构化数据
  ↓
[未来：models层存储到数据库]
```

---

## 📁 文件职责说明

### 1. ocr_engine.py（555行）
**职责**: 封装PaddleOCR引擎，提供统一的OCR识别接口

**核心方法**:
- `recognize(image_path, dpi=300)` - 识别图片中的文字
- `recognize_area(image, bbox)` - 识别指定区域的文字
- `load_calibration()` - 加载坐标校准函数

**依赖**: PaddleOCR, OpenCV, calibration_data/

---

### 2. pdf_parser.py（861行）
**职责**: 解析PDF文件，提取文本和表格，转换为结构化数据

**核心方法**:
- `parse(pdf_path)` - 解析完整PDF
- `parse_page(page_num)` - 解析单页
- `extract_tables()` - 提取表格
- `extract_text()` - 提取纯文本

**依赖**: pdfplumber, pdf2image, ocr_engine.py

**输出格式**:
```python
{
    "metadata": {"filename": "...", "pages": 3},
    "pages": [{
        "page_num": 1,
        "text": "...",
        "tables": [...],
        "keywords": {...}
    }]
}
```

---

### 3. image_splitter.py（1294行）
**职责**: 基于OCR识别的关键词位置，智能分割PDF页面为多个区块

**核心方法**:
- `split_by_keywords_two_stage()` - 两阶段分割（推荐）
- `split_horizontal(image, ratio=0.63)` - 横向63%分割
- `detect_horizontal_lines()` - 检测横线位置

**算法**:
```
1. OCR识别全页文字
2. 定位关键词（如"Total Sales"）
3. 基于关键词Y坐标初步分割
4. 检测横线优化分割边界
5. 输出各区块的图像+元数据
```

---

### 4. section_splitter.py（453行）
**职责**: 处理分割后的区块，提取业务数据

**核心方法**:
- `extract_sales_section()` - 提取销售明细
- `extract_refund_section()` - 提取退款明细
- `extract_fees_section()` - 提取费用明细

---

### 5. pdf_section_splitter.py（804行）
**职责**: 整合所有模块，提供完整的PDF处理流程

**核心函数**:
```python
result = process_pdf_complete("statement.pdf")
# 输入：PDF路径
# 输出：结构化数据字典
```

**处理流程**:
```
PDF → 解析页面 → OCR识别 → 区块分割 → 数据提取 → 输出JSON
```

---

## 🔴 代码注释铁律（强制执行）

> **详细示例请查看**: templates/目录中的模板文件

### 总体原则
**为3个月后的自己写注释，假设他完全忘记了当前上下文**

### 1. 文件头注释（必需）
```python
# ============================================================
# 文件: backend/app/services/example_service.py
# 功能: [一句话描述核心功能]
# 作者: [姓名或团队]
# 创建时间: 2025-12-15
# 最后修改: 2025-12-15
# 依赖: [列出核心依赖库]
# 说明: [可选：额外的重要说明]
# ============================================================
```

---

### 2. 函数docstring（必需）
**必须包含**:
- 功能描述（What）
- 实现原理（How）
- 设计原因（Why）
- 参数详解（Args）
- 返回值详解（Returns）
- 异常说明（Raises）
- 使用示例（Example）
- 注意事项（Note）

**标准格式**:
```python
def process_data(
    input_data: List[Dict],
    threshold: float = 0.8
) -> Dict[str, Any]:
    """处理输入数据，过滤并转换.

    核心流程：
    1. 过滤低质量数据（基于threshold）
    2. 转换为标准格式
    3. 聚合统计信息

    Args:
        input_data: 输入数据列表.
            格式：[{"key": "value"}, ...]
            要求：每个dict必须包含"key"字段
        threshold: 质量阈值.
            范围：0.0-1.0
            默认：0.8（经验值）
            说明：低于此值的数据将被过滤

    Returns:
        处理结果字典，包含：
        {
            "valid_count": 10,  # 有效数据数量
            "filtered_count": 2,  # 过滤数据数量
            "data": [...]  # 处理后的数据
        }

    Raises:
        ValueError: 当input_data为空时
        TypeError: 当threshold不是float时

    Example:
        >>> data = [{"key": "a", "score": 0.9}, {"key": "b", "score": 0.5}]
        >>> result = process_data(data, threshold=0.8)
        >>> result["valid_count"]
        1

    Note:
        - threshold默认0.8基于历史数据分析
        - 过滤后的数据不会返回，只统计数量
    """
    # 实现代码...
```

---

### 3. 类docstring（必需）
```python
class DataProcessor:
    """数据处理器，提供统一的数据处理接口.

    功能：
    - 数据验证
    - 数据转换
    - 数据聚合

    核心属性：
        threshold (float): 质量阈值
        logger (Logger): 日志记录器

    使用示例：
        >>> processor = DataProcessor(threshold=0.8)
        >>> result = processor.process(data)

    注意：
        - 首次使用会加载配置文件
        - 不支持多线程并发使用
    """
    pass
```

---

### 4. 魔法数字注释（必需）
```python
# ❌ 错误：裸露数字
if confidence > 0.8:
    pass

# ✅ 正确：常量+注释
CONFIDENCE_THRESHOLD = 0.8  # 经验阈值，误识别率<5%
if confidence > CONFIDENCE_THRESHOLD:
    pass
```

---

### 5. 复杂逻辑注释（必需）
对于复杂的算法、正则表达式、SQL查询，必须逐行或逐块注释：

```python
# 复杂正则表达式必须注释
pattern = r"""
    Total\s*Sales?     # 匹配"Total Sales"或"Total Sale"
    \s*[:\-]?          # 可选的冒号或横线分隔符
    \s*(\$?\d+[\d,]*\.?\d*)  # 匹配金额
"""

# 复杂算法必须注释
def detect_lines(image):
    """检测横线（使用霍夫变换）.

    步骤：
    1. 转换为灰度图
    2. Canny边缘检测
    3. 霍夫变换检测直线
    4. 过滤水平线
    5. 合并相邻线
    """
    # 步骤1: 转换为灰度图
    # 说明：霍夫变换只处理单通道图像
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # 步骤2: Canny边缘检测
    # 参数说明：
    # - 50: 低阈值
    # - 150: 高阈值
    edges = cv2.Canny(gray, 50, 150)

    # ... 后续步骤
```

---

### 6. 日志记录规范
```python
import logging

logger = logging.getLogger(__name__)

# 日志级别使用规范：
# DEBUG: 详细调试信息
# INFO: 关键流程节点
# WARNING: 可恢复的异常
# ERROR: 错误但不中断
# CRITICAL: 致命错误

def process_pdf(pdf_path):
    logger.info(f"开始处理PDF: {pdf_path}")

    try:
        logger.debug(f"PDF页数: {page_count}")
        # ... 处理逻辑
        logger.info(f"PDF处理完成: {pdf_path}")
    except Exception as e:
        logger.error(f"PDF处理失败: {pdf_path}", exc_info=True)
        raise
```

---

## 🧪 测试规范

### 测试文件组织
```
backend/tests/
├── unit/                    # 单元测试
│   ├── test_ocr_engine.py
│   ├── test_pdf_parser.py
│   └── test_image_splitter.py
├── integration/             # 集成测试
│   └── test_full_pipeline.py
├── test_data/               # 测试数据
│   └── sample_pdfs/
└── fixtures/                # 测试fixtures
    └── __init__.py
```

### 测试命名规范
```python
# 测试类：Test + 被测试的类名
class TestOCREngine:
    pass

# 测试方法：test_ + 场景描述
def test_recognize_text_success():  # 正常情况
    pass

def test_recognize_empty_image():   # 边界情况
    pass

def test_recognize_invalid_path():  # 异常情况
    pass
```

### 测试覆盖要求
每个函数至少包含3类测试：
1. **正常情况测试**（Happy Path）
2. **边界情况测试**（Edge Cases）
3. **异常情况测试**（Exception Cases）

```python
# 示例：测试process_data函数

def test_process_data_normal():
    """测试：正常输入."""
    data = [{"key": "a", "score": 0.9}]
    result = process_data(data, threshold=0.8)
    assert result["valid_count"] == 1

def test_process_data_empty():
    """测试：空输入."""
    result = process_data([], threshold=0.8)
    assert result["valid_count"] == 0

def test_process_data_invalid_threshold():
    """测试：无效阈值."""
    with pytest.raises(TypeError):
        process_data([{"key": "a"}], threshold="invalid")
```

---

## 🔧 开发工作流

### Git提交规范
```bash
# 格式：<type>(<scope>): <subject>

# type类型：
# - feat: 新功能
# - fix: 修复bug
# - docs: 文档更新
# - style: 代码格式
# - refactor: 重构
# - test: 测试相关
# - chore: 构建/工具配置

# 示例：
git commit -m "feat(ocr): 添加坐标校准功能"
git commit -m "fix(parser): 修复表格提取bug"
git commit -m "test(ocr): 添加边界情况测试"
```

---

## 🔐 安全注意事项

### 1. 文件上传验证
```python
ALLOWED_EXTENSIONS = {'pdf'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10MB
```

### 2. SQL注入防护
```python
# ❌ 错误：拼接SQL
query = f"SELECT * FROM users WHERE username = '{username}'"

# ✅ 正确：参数化查询
query = "SELECT * FROM users WHERE username = :username"
result = db.session.execute(query, {"username": username})
```

### 3. 敏感信息保护
```python
# 使用环境变量
import os
DATABASE_URL = os.getenv("DATABASE_URL")
SECRET_KEY = os.getenv("SECRET_KEY")

# .gitignore应包含：
# .env
# *.pkl（可能包含敏感截图）
# test_results/
```

---

## 📖 参考资源

### 官方文档
- [PaddleOCR文档](https://github.com/PaddlePaddle/PaddleOCR)
- [pdfplumber文档](https://github.com/jsvine/pdfplumber)
- [OpenCV Python教程](https://docs.opencv.org/4.x/d6/d00/tutorial_py_root.html)
- [pytest文档](https://docs.pytest.org/en/stable/)

### 项目相关文档
- **数据库设计**: [specs/db-design.md](specs/db-design.md)
- **性能优化**: [specs/performance.md](specs/performance.md)
- **OCR策略**: [specs/ocr-guide.md](specs/ocr-guide.md)

---

## 🚀 扩展阅读

### 详细文档索引
- **数据库设计详情** → [specs/db-design.md](specs/db-design.md)（500行）
  - 8张表结构
  - ER关系图
  - 常用查询示例
  - SQLAlchemy模型

- **性能优化指南** → [specs/performance.md](specs/performance.md)（550行）
  - OCR优化策略
  - 图像处理优化
  - 数据库优化
  - 性能分析工具

- **代码模板** → [templates/](templates/)目录（待创建）
  - 函数模板
  - 测试模板
  - Docstring模板

---

**END OF CORE.md (精简版)**

*配置版本: v4.0 | 最后更新: 2025-12-16 | 文件行数: 约400行（从1090行精简63%）*
